<?php


class ConnexionModele extends ModeleGenerique {

	
}


?>
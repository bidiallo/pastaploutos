<?php


class ModeleProfilException extends ModeleGeneriqueException {

	
}


?>
<?php


	class ModeleAccueil extends ModeleGenerique {


	}

			


?>







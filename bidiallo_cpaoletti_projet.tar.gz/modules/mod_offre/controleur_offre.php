<?php
require_once('modele_offre.php');
require_once('vue_offre.php');
require_once('include/controleur_generique.php');

class ControleurOffre extends ControleurGenerique{
	function __construct(){
		$this->vue=new VueOffre();
		$this->modele=new ModeleOffre();
	}

		function consulter_recette() {

		$element = $this->modele->modele_recuperer_info_offre($_GET['id_offre']);
		$this->vue->vue_consulter_offre($element);
	}

		function liste_recette() {
			
		$recette = $this->modele->modele_offre();
		$this->vue->vue_liste_offre($offre);
	}

		function favoris_recette(){

			if(!isset($_SESSION['id_user']) || $_SESSION['id_user'] == "") {
			$this->vue->vue_erreur(" Impossible d'ajouter aux favoris. Vous n'etes pas connecté.");

		}elseif ($_GET['is_favoris']==1) {

			$this->vue->vue_erreur(" Recette déjà ajoutée aux favoris !!");
		}

		else {
			try{
			$element = $this->modele->modele_ajouter_favoris($_GET['id_recette']);
			$this->vue->vue_consulter_recette($element);
			} catch(Exception $e) {
				//$this->vue->vue_erreur("Erreur accès BDD");
			}
		}


		}

}
?>
<?php

require_once('include/controleur_generique.php');
require_once('include/module_generique.php');
require_once('controleur_offre.php');


class ModOffre extends ModuleGenerique {

	function __construct() {

		$action = isset($_GET['action']) ? $_GET['action'] : "default";		

		parent::__construct();
		
		$this -> controleur = new ControleurOffre();

		switch ($action) {
			case 'consulter_recette':
				$this->controleur->consulter_recette();
				break;

			case 'liste_recette' :
				$this->controleur-> liste_recette();
				break;

			case 'favoris_recette' :
				$this->controleur->favoris_recette();
				break;

			default:
				$this->controleur->liste_recette();
				break;
		}
	}
}

?>
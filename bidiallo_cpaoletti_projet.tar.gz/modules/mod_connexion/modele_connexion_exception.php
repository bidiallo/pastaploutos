<?php

	class ModeleConnexionException extends ModeleGeneriqueException {
		
	}

?>
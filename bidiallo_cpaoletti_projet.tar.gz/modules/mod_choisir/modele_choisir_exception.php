<?php
require_once('include/modele_generique_exception.php');

class ModeleChoisirException extends ModeleGeneriqueException {
	
}

?>
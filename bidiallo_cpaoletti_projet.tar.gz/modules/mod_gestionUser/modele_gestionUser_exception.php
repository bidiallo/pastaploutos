<?php


class ModeleGestionUserException extends ModeleGeneriqueException {

	
}


?>
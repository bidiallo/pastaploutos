<?php


class ModeleGeneriqueException extends Exception {

}